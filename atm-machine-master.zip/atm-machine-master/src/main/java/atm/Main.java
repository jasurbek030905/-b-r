package atm;

/**
 * Main class to run the application
 * 
 * @author Artiom
 *
 */
public class Main {

	public static void main(String[] args) {
		App.main(args);
	}

}

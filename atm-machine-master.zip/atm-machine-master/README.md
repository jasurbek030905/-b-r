<h1 align="center"><strong><em>ATM Machine</strong></em></h1>
<p align="center"><img src="https://www.pngkey.com/png/full/202-2026654_atm-machine-transparent-png-atm-machines.png" alt="atm logo" height=450 width=225></p>
  
# How to run the app?

<p>To run this application: </p> 

* You have to have Java installed. You can download it here: <a href="https://www.java.com/en/">Link</a>
* After that accees the <a href="https://github.com/Yashmerino/A-M/releases">Releases</a> section and download the last version of the application.
* Right-click the zipped folder saved to your computer and choose "Extract All". Run the application and enjoy!

<h1 align="center"><strong>Demonstration</strong></h1>
<p align="center"><img src="img/1.png" height=450 width=600></p>
<p align="center"><img src="img/2.png" height=450 width=600></p>
<p align="center"><img src="img/3.png" height=450 width=600></p>
<p align="center"><img src="img/4.png" height=450 width=600></p>
<p align="center"><img src="img/5.png" height=450 width=600></p>
<p align="center"><img src="img/6.png" height=450 width=600></p>
